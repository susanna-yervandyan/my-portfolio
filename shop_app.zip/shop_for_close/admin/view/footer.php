<footer>
    <p>This is footer section</p>
</footer>

<script src = "../assets/js/script.js"></script>
</body>
</html>